module.exports = {

	// FusionAuth info (copied from the FusionAuth admin panel)
	clientID: 'f38f99cb-deb2-4469-97a8-8c033cdd5fe6',
	clientSecret: 'ZGZ_9_0fwyl3pGz9CaNPWb4O_cvDf6gcS3_nwsm9zI4',
	redirectURI: 'http://localhost:9000/oauth-callback',
	applicationID: 'f38f99cb-deb2-4469-97a8-8c033cdd5fe6',

	// our FusionAuth api key
	apiKey: '0BO8QAj8cqt_o9kDX8l7VCbvtue5yBsg0XVHo_6xp3b_oXcSVv3BdlG2',
	//apiKey: 'bf69486b-4733-4470-a592-f1bfce7af580',

	// ports
	clientPort: 8080,
	serverPort: 9000,
	fusionAuthPort: 9011
};
